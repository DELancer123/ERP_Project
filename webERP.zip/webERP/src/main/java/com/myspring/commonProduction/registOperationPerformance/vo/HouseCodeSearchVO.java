package com.myspring.commonProduction.registOperationPerformance.vo;

public class HouseCodeSearchVO {
	private String houseCode;
	private String houseName;
	
	public HouseCodeSearchVO() {
	}

	public String getHouseCode() {
		return houseCode;
	}

	public void setHouseCode(String houseCode) {
		this.houseCode = houseCode;
	}

	public String getHouseName() {
		return houseName;
	}

	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}
	
	
}
