package com.myspring.systemmag.service;

import com.myspring.systemmag.vo.SystemmagVO;

public interface SystemmagService {
	public void addCompany(SystemmagVO systemmagVO) throws Exception;
}
