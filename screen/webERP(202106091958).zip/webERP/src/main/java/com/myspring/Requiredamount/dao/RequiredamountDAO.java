package com.myspring.Requiredamount.dao;

import java.util.List;

public interface RequiredamountDAO {

	List selectAllMrpList() throws Exception;

}
