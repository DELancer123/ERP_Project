//package com.myspring.salesmanage.pop.itemview.service;
//
//import java.util.List;
//
//import org.springframework.dao.DataAccessException;
//
//public interface ItemViewService {
//
//	public List itemSearch() throws DataAccessException;
//	public List planItemView() throws DataAccessException;
//	public List itemIn(String Item_Code) throws DataAccessException;
//	public List viewSearch(String Item_Code) throws DataAccessException;
//}
//
//
//
