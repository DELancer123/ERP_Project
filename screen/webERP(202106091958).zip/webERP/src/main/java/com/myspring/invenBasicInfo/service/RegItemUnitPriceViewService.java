//package com.myspring.invenBasicInfo.service;
//
//import java.util.List;
//
//import org.springframework.dao.DataAccessException;
//
//
//public interface RegItemUnitPriceViewService {
//	public List viewRegItemUnitPrice() throws DataAccessException;
//	public List viewPopRegItemUnitPrice() throws DataAccessException;
//}
