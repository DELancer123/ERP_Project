//package com.myspring.salesmanage.pop.custView.dao;
//
//import java.util.List;
//
//import org.springframework.dao.DataAccessException;
//
//public interface CustViewDAO {
//
//	public List viewCust() throws DataAccessException; //고객리스?�� 출력
////	public List viewPop() throws DataAccessException;
//	public List setText(String General_Customer_Code) throws DataAccessException;
//	public List searchView(String General_Customer_Code) throws DataAccessException;
//	
//}
