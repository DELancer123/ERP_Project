package com.myspring.Billing.service;

import java.util.List;

import com.myspring.Billing.vo.BIllIngVO;

public interface BIllIngService {

	List<BIllIngVO> selectAllcmList() throws Exception;

}
