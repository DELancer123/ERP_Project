//package com.myspring.salesmanage.salesplan.sta.service;
//
//import java.sql.Date;
//import java.util.List;
//
//import org.springframework.dao.DataAccessException;
//
//import com.myspring.salesmanage.salesplan.vo.SalesplanVO;
//
//public interface SalesplanStaService {
//
//	public List listSalesplans() throws DataAccessException;
//	public SalesplanVO searchCode(String Item_Code) throws Exception;
//	public SalesplanVO searchDate(Date Plan_Date) throws Exception;
//	public SalesplanVO searchGroup(String Item_Group_Code) throws Exception;
//
//}
