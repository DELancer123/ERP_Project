//package com.myspring.salesmanage.pop.itemview.vo;
//
//import org.springframework.stereotype.Component;
//
//@Component("itemviewVO")
//public class ItemViewVO {
//	
//	private String Item_Code; //ǰ��
//	private String Item_Name; //ǰ��
//	private String Standard; //�԰�
//	private String Inventory_Unit; //����
//	private String Inspection_Status; //�˻翩��
//	
//	public ItemViewVO() {}
//	
//	public ItemViewVO(String Item_Code, String Item_Name, String Standard, String Inventory_Unit, String Inspection_Status) {
//		 this.Item_Code = Item_Code; //ǰ��
//		 this.Item_Name = Item_Name; //ǰ��
//		 this.Standard = Standard; //�԰�
//		 this.Inventory_Unit = Inventory_Unit; //����
//		 this.Inspection_Status = Inspection_Status; //�˻翩��
//	}
//	
//	public String getItem_Code() {
//		return Item_Code;
//	}
//	public void setItem_Code(String item_Code) {
//		Item_Code = item_Code;
//	}
//	public String getItem_Name() {
//		return Item_Name;
//	}
//	public void setItem_Name(String item_Name) {
//		Item_Name = item_Name;
//	}
//	public String getStandard() {
//		return Standard;
//	}
//	public void setStandard(String standard) {
//		Standard = standard;
//	}
//	public String getInventory_Unit() {
//		return Inventory_Unit;
//	}
//	public void setInventory_Unit(String inventory_Unit) {
//		Inventory_Unit = inventory_Unit;
//	}
//	public String getInspection_Status() {
//		return Inspection_Status;
//	}
//	public void setInspection_Status(String inspection_Status) {
//		Inspection_Status = inspection_Status;
//	}
//
//}
