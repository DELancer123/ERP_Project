package com.myspring.Billing.dao;

import java.util.List;

public interface BIllIngDAO {

	List selectAllcmList() throws Exception;

}
