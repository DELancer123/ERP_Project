package com.myspring.MainPlan.dao;

import java.util.List;

public interface MainPlanDAO {

	List selectAllMainPlanList() throws Exception;

	List selectAllMpsosList() throws Exception;

}
