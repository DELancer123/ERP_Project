/*
 * package com.myspring.invenBasicInfo.regItemUnitPrice.vo;
 * 
 * import org.springframework.stereotype.Component;
 * 
 * @Component("itemVO") public class ItemVO { private String Item_Code; //품번
 * private String Item_Name; //품명 private String Standard; //규격 private String
 * Inventory_Unit; //단위 private String Kind; //종류(구매,판매) private String
 * Purchase_Price; //구매 단가 private String Sales_Price; //판매 단가, 구매단가 입력시 Null
 * 
 * public ItemVO() { super(); }
 * 
 * public String getItem_Code() { return Item_Code; }
 * 
 * public void setItem_Code(String item_Code) { Item_Code = item_Code; }
 * 
 * public String getItem_Name() { return Item_Name; }
 * 
 * public void setItem_Name(String item_Name) { Item_Name = item_Name; }
 * 
 * public String getStandard() { return Standard; }
 * 
 * public void setStandard(String standard) { Standard = standard; }
 * 
 * public String getInventory_Unit() { return Inventory_Unit; }
 * 
 * public void setInventory_Unit(String inventory_Unit) { Inventory_Unit =
 * inventory_Unit; }
 * 
 * public String getKind() { return Kind; }
 * 
 * public void setKind(String kind) { Kind = kind; }
 * 
 * public String getPurchase_Price() { return Purchase_Price; }
 * 
 * public void setPurchase_Price(String purchase_Price) { Purchase_Price =
 * purchase_Price; }
 * 
 * public String getSales_Price() { return Sales_Price; }
 * 
 * public void setSales_Price(String sales_Price) { Sales_Price = sales_Price; }
 * 
 * 
 * }
 */