/*
 * package com.myspring.invenBasicInfo.service;
 * 
 * import java.util.List;
 * 
 * import org.springframework.dao.DataAccessException;
 * 
 * import com.myspring.invenBasicInfo.regItemUnitPrice.vo.ItemVO;
 * 
 * public interface ItemViewService { public List itemView() throws
 * DataAccessException; public List popView() throws DataAccessException; public
 * List setText(String Item_Code)throws DataAccessException; public List
 * SearchView(String Item_Code) throws DataAccessException; public List
 * itemSet() throws DataAccessException; public int addItem(ItemVO itemVO)
 * throws DataAccessException; public int updateItem(ItemVO itemVO) throws
 * DataAccessException; }
 */