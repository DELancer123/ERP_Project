package com.myspring.commonProduction.operationRegist.vo;

public class DepartmentViewVO {
   private String departmentCode;
   private String departmentName;
   
   public DepartmentViewVO() {
   }

   public String getDepartmentCode() {
      return departmentCode;
   }

   public void setDepartmentCode(String departmentCode) {
      this.departmentCode = departmentCode;
   }

   public String getDepartmentName() {
      return departmentName;
   }

   public void setDepartmentName(String departmentName) {
      this.departmentName = departmentName;
   }
   
   
}