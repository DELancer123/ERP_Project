package com.myspring.commonProduction.registOperationPerformance.vo;

public class ProcessCodeSearchVO {
	private String processCode;
	private String processName;
	
	public ProcessCodeSearchVO() {	
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}
	
	
}
