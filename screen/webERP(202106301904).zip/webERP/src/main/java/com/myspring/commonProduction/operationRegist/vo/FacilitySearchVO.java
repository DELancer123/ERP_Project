package com.myspring.commonProduction.operationRegist.vo;

public class FacilitySearchVO {
	private String productionFacility;
	private String taskTeam;
	
	public FacilitySearchVO() {
	}

	public String getProductionFacility() {
		return productionFacility;
	}

	public void setProductionFacility(String productionFacility) {
		this.productionFacility = productionFacility;
	}

	public String getTaskTeam() {
		return taskTeam;
	}

	public void setTaskTeam(String taskTeam) {
		this.taskTeam = taskTeam;
	}
	
	
}
