package com.myspring.commonProduction.operationRegist.vo;

public class FactoryViewVO {
	private String workplaceCode;
	private String workplaceName;
	
	public FactoryViewVO() {
	}

	public String getWorkplaceCode() {
		return workplaceCode;
	}

	public void setWorkplaceCode(String workplaceCode) {
		this.workplaceCode = workplaceCode;
	}

	public String getWorkplaceName() {
		return workplaceName;
	}

	public void setWorkplaceName(String workplaceName) {
		this.workplaceName = workplaceName;
	}
	
	
}
