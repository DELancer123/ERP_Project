package com.myspring.salesmanage.forward.reg.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.myspring.salesmanage.forward.vo.ForwardVO;

public interface ForwardRegController {

	public ModelAndView submitCust(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView listForwardCode(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView addForward(@ModelAttribute("forward") ForwardVO forwardVO, HttpServletRequest request,
			HttpServletResponse response) throws Exception;
	public ModelAndView delForward(HttpServletRequest request, HttpServletResponse response) throws Exception ;
	
	public ModelAndView itemTableView(ForwardVO forwardVO, HttpServletRequest request, HttpServletResponse response) throws Exception;

	public ModelAndView addCustcode(HttpServletRequest request, HttpServletResponse response) throws Exception;
//	public ModelAndView listSubForwardCode(HttpServletRequest request, HttpServletResponse response) throws Exception;
	public ModelAndView delSubForward(HttpServletRequest request, HttpServletResponse response) throws Exception ;
}
