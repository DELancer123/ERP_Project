package com.myspring.commonProduction.registOperationPerformance.vo;

public class WorkplaceCodeSearchVO {
	private String workplaceCode;
	private String workplaceName;
	
	public WorkplaceCodeSearchVO() {	
	}

	public String getWorkplaceCode() {
		return workplaceCode;
	}

	public void setWorkplaceCode(String workplaceCode) {
		this.workplaceCode = workplaceCode;
	}

	public String getWorkplaceName() {
		return workplaceName;
	}

	public void setWorkplaceName(String workplaceName) {
		this.workplaceName = workplaceName;
	}
	
	
}
